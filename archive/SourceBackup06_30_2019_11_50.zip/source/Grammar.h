#pragma once

#include "stdafx.h"
#include "View.h"	

extern HFONT font;
extern COLORREF gray0, gray1, gray2;
extern HBRUSH hgray1;
extern COLORREF green0, green1, green2;
extern HBRUSH hgreen1;

#define GRAMMARSTRING_LENGTH  12

class Grammar {
public:
	HWND hWnd;
	HDC hdcMem;
	HBITMAP hbmMem, hbmOld;
	HBRUSH hbrBkGnd;
	HFONT hfntOld;
	HWND grammarStringEditField;
	bool isVisible;

	char grammarString[GRAMMARSTRING_LENGTH + 4]; // 20 bytes

	Grammar() {
		grammarStringEditField = NULL;
		hWnd = NULL;
		hdcMem = NULL;
		hbmMem = NULL;
		hbmOld = NULL;
		hbrBkGnd = NULL;
		hfntOld = NULL;
		isVisible = true;
	}

	void create(HWND parent, HINSTANCE inst);
	void createHandler();

	bool keyDown(int key);
	void keyUp(int key);

	void refresh(bool alsoCompute = true);
	void drawWindow();
	bool parameterWasEdited();

	void randomGrammarString();
	void updateAfterRandomChanges();
	void dowloadGrammarString();
	void toggleVisible();
	void equationSelected();
};

extern Grammar grammar;
