#include "stdafx.h"
#include "Grammar.h"
#include "Fractal.h"
#include <time.h>

HFONT font = NULL;
COLORREF gray0 = RGB(60, 60, 60);
COLORREF gray1 = RGB(128, 128, 128);
COLORREF gray2 = RGB(200, 200, 200);
COLORREF green0 = RGB(60, 60 + 50, 60);
COLORREF green1 = RGB(128, 128 + 50, 128);
COLORREF green2 = RGB(200, 200 + 50, 200);
HBRUSH hgray1 = CreateSolidBrush(gray1);
HBRUSH hgreen1 = CreateSolidBrush(green1);
HBRUSH hred1 = CreateSolidBrush(RGB(148, 108, 108));
extern HWND g_hWnd;

Grammar grammar;

// ================================================================================

WNDPROC originalEditBoxHandler;

LRESULT CALLBACK EditProc(HWND hEdit, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int chr;
	bool imageRecalcRequired = false;

	switch (msg) {
	case WM_CHAR:
		chr = toupper(LOWORD(wParam));
		if (chr != VK_BACK && (chr < 'A' || chr >('A' + EQU_MAX - 2))) {
			SendMessage(g_hWnd, WM_KEYDOWN, wParam, lParam);
			return 0;
		}
		imageRecalcRequired = true;
		break;
	case WM_DESTROY:
		SetWindowLong(hEdit, GWL_WNDPROC, (LONG)originalEditBoxHandler);
		return 0;
	}

	LRESULT ret = CallWindowProc(originalEditBoxHandler, hEdit, msg, wParam, lParam);

	if (imageRecalcRequired)
		grammar.refresh();

	return ret;
}

// ================================================================================
static char* CLASS_NAME = (char*)"Grammar";
#define HELP_BUTTON  2000

LRESULT CALLBACK GrammarWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case WM_CREATE:
		grammar.hWnd = hWnd;
		grammar.createHandler();
		break;
	case WM_COMMAND:
		grammar.refresh();
		break;

	case WM_PAINT :
	{	
		RECT rc = { 0 };
	PAINTSTRUCT ps;
	HDC hdc = BeginPaint(hWnd, &ps);

	GetClientRect(hWnd, &rc);
	FillRect(hdc, &rc, hgray1);
	}
	break;

	//case WM_CHAR:
	//	SendMessage(grammar.grammarStringEditField, WM_KEYDOWN, wParam, lParam);
	//	return 0;
	//case WM_KEYDOWN:
	//	chr = LOWORD(wParam);
	//	if (chr == VK_BACK || chr == VK_DELETE)
	//		imageRecalcRequired = true;
	//	else {
	//		if (chr < 'A' || chr >('A' + EQU_MAX - 2)) {
	//			SendMessage(g_hWnd, WM_KEYDOWN, wParam, lParam);
	//			return 0;
	//		}

	//		PostMessage(hEdit, WM_CHAR, wParam, lParam);
	//		return 0;
	//	}
	//	break;


	case WM_KEYDOWN :
		SendMessage(grammar.grammarStringEditField, WM_CHAR, wParam, lParam);
		return 0;
	case WM_DESTROY:
		DeleteObject(grammar.hWnd);
		DeleteObject(font);
		DeleteObject(grammar.hdcMem);
		DeleteObject(grammar.hbmMem);
		DeleteObject(grammar.hbmOld);
		DeleteObject(grammar.hbrBkGnd);
		DeleteObject(grammar.hfntOld);
		DeleteObject(grammar.grammarStringEditField);
		DeleteObject(hgray1);
		DeleteObject(hgreen1);
		DeleteObject(hred1);
		return TRUE;

	case WM_ERASEBKGND:
		return (LRESULT)1;
	}

	return DefWindowProc(hWnd, message, wParam, lParam);
}

// ================================================================================

void Grammar::create(HWND parent, HINSTANCE hInstance) {
	WNDCLASSEX wcex;
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = GrammarWndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = NULL;
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = CLASS_NAME;
	wcex.hIconSm = NULL;

	if (!RegisterClassEx(&wcex)) {
		MessageBox(NULL, "Widget Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		exit(-1);
	}

	RECT rc2 = { 100, 100, 100 + 290,100 + 700 };
	AdjustWindowRect(&rc2, WS_OVERLAPPEDWINDOW, FALSE);

	hWnd = CreateWindow(CLASS_NAME, "Grammar", WS_OVERLAPPED | WS_BORDER | WS_CLIPCHILDREN, CW_USEDEFAULT, CW_USEDEFAULT,
		rc2.right - rc2.left, rc2.bottom - rc2.top, parent, NULL, hInstance, NULL);
	if (hWnd == NULL) {
		MessageBox(NULL, "Grammar Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		exit(-1);
	}

	//CreateWindow("BUTTON", "Help", WS_CHILD | WS_VISIBLE, 46, 665, 65, 22, hWnd, (HMENU)HELP_BUTTON, 0, 0);

	ShowWindow(hWnd, SW_SHOWNORMAL);
	SetFocus(hWnd);

	font = CreateFont(20, 8, 0, 0, 600, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_ROMAN, "Courier New");
}

// ================================================================================

void Grammar::createHandler() {
	grammarStringEditField = CreateWindow("EDIT", NULL, WS_VISIBLE | WS_CHILD | ES_UPPERCASE, 15, 15, 140, 16, hWnd, HMENU(20), NULL, NULL);
	originalEditBoxHandler = (WNDPROC)SetWindowLong(grammar.grammarStringEditField, GWL_WNDPROC, (LONG)EditProc);

	HWND hk = CreateWindow("EDIT", NULL, WS_VISIBLE | WS_CHILD | ES_MULTILINE | ES_READONLY, 15, 45, 240, 460, hWnd, HMENU(21), NULL, NULL);
	char s2[64],str[2000] = { 0 };
	for (int i = 1; i < EQU_MAX; ++i) {
		sprintf_s(s2, 63,"%c: %s\r\n", 'A' + i - 1, equationName[i]);
		strcat_s(str, 1999,s2);
	}
	SetWindowTextA(hk, str);

	srand(unsigned int(time(NULL)));
}

// ================================================================================

void Grammar::updateAfterRandomChanges() {
	SetWindowTextA(grammarStringEditField, grammarString);

	dowloadGrammarString();
//	compute();
}

void Grammar::randomGrammarString() {
	int length = 1 + (rand() % GRAMMARSTRING_LENGTH);
	for (int j = 0; j < length; ++j)
		grammarString[j] = '1' + (rand() % (EQU_MAX-1));
	grammarString[length] = 0;

	updateAfterRandomChanges();
}
void Grammar::equationSelected() {
	grammarString[0] = 'A' + EQUATION - 1;
	grammarString[1] = 0;
	SetWindowTextA(grammarStringEditField, grammarString);
}

// ================================================================================

void Grammar::dowloadGrammarString() {
	int i;
	char str[GRAMMARSTRING_LENGTH + 1];
	GetWindowTextA(grammarStringEditField, str, GRAMMARSTRING_LENGTH);
	
	for (i = 0; i < GRAMMARSTRING_LENGTH; ++i) {
		if (str[i] == 0) break;
		control.grammarString[i].x = int(1 + str[i] - 'A'); // base 1 equation index
	}

	control.grammarString[i].x = 0;
}

// ================================================================================
// repaint dialog. also calculate the image if specified

void Grammar::refresh(bool alsoCompute) {
	InvalidateRect(hWnd, NULL, TRUE);
	if (alsoCompute) 
		fractal.isDirty = true;
}

void Grammar::toggleVisible() {
	ShowWindow(hWnd, isVisible ? SW_HIDE : SW_SHOWNORMAL);
	isVisible = !isVisible;
}

